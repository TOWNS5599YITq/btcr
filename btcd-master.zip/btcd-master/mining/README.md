mining
======

[![Build Status](https://github.com/btcsuite/btcd/workflows/Build%20and%20Test/badge.svg)](https://github.com/btcsuite/btcd/actions)
[![ISC License](http://img.shields.io/badge/license-ISC-blue.svg)](http://copyfree.org)
[![GoDoc](https://img.shields.io/badge/godoc-reference-blue.svg)](https://pkg.go.dev/github.com/btcsuite/btcd/mining)

## Overview

This package is currently a work in progress.

## Installation and Updating

```bash
$ go get -u github.com/btcsuite/btcd/mining
```

## License

Package mining is licensed under the [copyfree](http://copyfree.org) ISC
License.
